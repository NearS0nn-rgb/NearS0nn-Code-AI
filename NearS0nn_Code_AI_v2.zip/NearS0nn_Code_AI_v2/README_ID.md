# NearS0nn Code AI v2

Versi React + Vite dengan backend Netlify Functions dan Gemini API. Fitur: generate kode, debug, explain, dan chat pemrograman.

## Penting sebelum deploy

- ZIP ini berisi source code, bukan build statis siap drag-and-drop. Deploy sebagai proyek melalui GitHub yang dihubungkan ke Netlify agar Netlify menjalankan build dan Functions.
- Kamu perlu API key sendiri dari Google AI Studio. Akses gratis tersedia untuk model/kuota tertentu, tetapi batas dan ketersediaannya dapat berubah.
- Jangan pernah menaruh API key di `src/`, file frontend, screenshot, chat publik, atau repository GitHub.
- Jangan commit file `.env`. File `.env.example` hanya contoh dan tidak berisi key asli.

## Deploy dari HP Android

### 1. Dapatkan API key
1. Buka Google AI Studio: https://aistudio.google.com/
2. Masuk ke akun dan buat API key untuk proyekmu.
3. Simpan key secara privat. Jangan kirim key ke orang lain.

### 2. Upload source ZIP ke GitHub
1. Ekstrak `NearS0nn_Code_AI_v2.zip` di HP jika diperlukan.
2. Buka https://github.com/ dan buat repository baru, misalnya `nears0nn-code-ai`.
3. Upload isi folder proyek ke repository. Pastikan `package.json`, `src/`, `netlify/`, dan `netlify.toml` berada di root repository, bukan di dalam folder bertingkat lain.
4. Pastikan tidak ada API key asli di file yang diunggah.

### 3. Hubungkan ke Netlify
1. Buka https://app.netlify.com/ dan login.
2. Pilih **Add new site / Import an existing project**.
3. Pilih GitHub lalu repository `nears0nn-code-ai`.
4. Build command: `npm run build`
5. Publish directory: `dist`
6. Functions directory: `netlify/functions` (sudah ditulis di `netlify.toml`).
7. Mulai deploy.

### 4. Tambahkan API key di Netlify
1. Buka site di dashboard Netlify.
2. Masuk ke **Site configuration** atau **Project configuration → Environment variables** (nama menu dapat berubah).
3. Tambahkan `GEMINI_API_KEY` dengan nilai API key dari Google AI Studio.
4. Opsional: tambahkan `GEMINI_MODEL` dengan nilai `gemini-2.5-flash`. Jika model itu tidak tersedia untuk akunmu, pilih nama model yang tersedia di Google AI Studio.
5. Jalankan deploy baru / **Trigger deploy** supaya function membaca environment variable terbaru.

### 5. Tes
1. Buka URL situs Netlify.
2. Tanyakan dua pertanyaan berbeda, misalnya:
   - `Buat fungsi Python untuk menghitung luas persegi.`
   - `Kenapa kode print('hello) error? Perbaiki.`
3. Jika gagal, periksa pesan yang tampil dan **Functions logs** di Netlify.

## Jalankan lokal (opsional)
Butuh komputer dengan Node.js:
```bash
npm install
npm run dev
```
Untuk menguji Netlify Functions secara lokal, gunakan Netlify CLI atau plugin Netlify Vite sesuai dokumentasi resmi.

## Keamanan & batasan
- API key hanya dibaca server dari `process.env.GEMINI_API_KEY`.
- Jangan memasukkan API key ke frontend.
- Fungsi ini membatasi panjang input dan jumlah riwayat yang dikirim, tetapi belum memiliki autentikasi atau rate limiting per pengguna. Jangan bagikan endpoint secara luas tanpa menambahkan perlindungan tambahan karena pemakaian API dapat menghabiskan kuota.
- Paket gratis dan rate limit bergantung pada model, negara, akun, dan ketentuan penyedia. Tidak ada jaminan pemakaian tanpa batas.
- Percakapan tidak disimpan ke database; riwayat hanya berada di memori halaman selama tab terbuka.
- Periksa kebijakan privasi dan ketentuan penyedia API sebelum mengirim informasi sensitif.

## Struktur
```text
NearS0nn_Code_AI_v2/
├── index.html
├── package.json
├── netlify.toml
├── src/
│   ├── App.jsx
│   ├── main.jsx
│   └── style.css
└── netlify/
    └── functions/
        └── chat.mjs
```
