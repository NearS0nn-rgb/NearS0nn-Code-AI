import { useEffect, useRef, useState } from "react";

const modes = [
  { id: "coding", label: "Generate kode", icon: "</>" },
  { id: "debug", label: "Debug", icon: "⌘" },
  { id: "explain", label: "Jelaskan kode", icon: "?" },
  { id: "chat", label: "Chat coding", icon: "✦" },
];

const welcome = {
  role: "assistant",
  content: "Halo! Gue NearS0nn Code AI, asisten coding lu. Gue bisa bantu bikin kode, mencari bug, menjelaskan kode, atau ngobrol soal pemrograman. Pilih mode di bawah atau langsung ketik pertanyaan. 🚀",
};

export default function App() {
  const [mode, setMode] = useState("coding");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([welcome]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, busy]);

  async function sendMessage(text = input) {
    const prompt = text.trim();
    if (!prompt || busy) return;
    const userMessage = { role: "user", content: prompt };
    const next = [...messages, userMessage];
    setMessages(next);
    setInput("");
    setError("");
    setBusy(true);

    try {
      const history = next
        .filter((m) => m.role === "user" || m.role === "assistant")
        .slice(-12)
        .map((m) => ({ role: m.role, content: m.content }));

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: prompt, mode, history }),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data.error || `Request gagal (${response.status}).`);
      }
      if (!data.reply) throw new Error("Model mengirim jawaban kosong. Coba lagi.");
      setMessages((current) => [...current, { role: "assistant", content: data.reply }]);
    } catch (err) {
      setError(err.message || "Tidak bisa menghubungi AI. Periksa koneksi dan konfigurasi API.");
    } finally {
      setBusy(false);
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    sendMessage();
  }

  function resetChat() {
    if (busy) return;
    setMessages([welcome]);
    setError("");
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">N<span>0</span></div>
          <div><strong>NearS0nn</strong><small>CODE AI</small></div>
        </div>
        <button className="new-chat" onClick={resetChat}>＋ <span>Chat baru</span></button>
        <div className="side-label">TOOLS</div>
        <nav className="mode-list" aria-label="Mode AI">
          {modes.map((item) => (
            <button key={item.id} className={`mode-button ${mode === item.id ? "selected" : ""}`} onClick={() => setMode(item.id)}>
              <span className="mode-icon">{item.icon}</span>{item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="status-dot" /> <span>AI via Gemini API</span>
          <small>Jaga API key tetap rahasia.</small>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="mobile-brand"><span className="brand-mark mini">N<span>0</span></span><strong>NearS0nn Code AI</strong></div>
          <div className="model-chip"><span className="pulse" /> Gemini · coding assistant</div>
          <button className="clear-button" onClick={resetChat} disabled={busy}>Reset chat</button>
        </header>

        <section className="conversation">
          {messages.length === 1 && (
            <div className="hero">
              <div className="hero-badge"><span className="pulse" /> YOUR AI CODING PARTNER</div>
              <h1>Build something<br /><span>brilliant.</span></h1>
              <p>Ngoding lebih gampang. Tanya, debug, pahami, lalu kembangkan ide lu.</p>
              <div className="suggestions">
                {[
                  ["Generate kode", "Buat program Python kalkulator sederhana dan jelaskan cara menjalankannya."],
                  ["Cari bug", "Debug kode ini dan jelaskan kesalahannya: print('Hello World)"],
                  ["Belajar coding", "Jelaskan perbedaan HTML, CSS, JavaScript, dan Python untuk pemula."],
                ].map(([title, prompt]) => (
                  <button className="suggestion" key={title} onClick={() => { setMode(title === "Cari bug" ? "debug" : title === "Belajar coding" ? "explain" : "coding"); sendMessage(prompt); }}>
                    <span>{title}</span><span className="suggestion-arrow">↗</span><small>{prompt}</small>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="message-list">
            {messages.map((message, i) => (
              <article className={`message ${message.role}`} key={`${i}-${message.role}`}>
                <div className="avatar">{message.role === "assistant" ? "N" : "YOU"}</div>
                <div className="message-body">
                  <div className="message-name">{message.role === "assistant" ? "NearS0nn AI" : "Lu"}{i === 0 && message.role === "assistant" ? <span className="welcome-tag">WELCOME</span> : null}</div>
                  <div className="message-content">{message.content}</div>
                </div>
              </article>
            ))}
            {busy && <article className="message assistant"><div className="avatar">N</div><div className="message-body"><div className="message-name">NearS0nn AI</div><div className="typing"><span/><span/><span/> <small>Lagi mikir...</small></div></div></article>}
            <div ref={endRef} />
          </div>
        </section>

        <footer className="composer-area">
          {error && <div className="error-box"><strong>Belum berhasil.</strong> {error}<small>Pastikan GEMINI_API_KEY sudah ditambahkan di Netlify dan deploy ulang.</small></div>}
          <div className="mode-tabs">
            {modes.map((item) => <button key={item.id} onClick={() => setMode(item.id)} className={mode === item.id ? "active" : ""}>{item.icon} {item.label}</button>)}
          </div>
          <form className="composer" onSubmit={handleSubmit}>
            <textarea value={input} onChange={(e) => setInput(e.target.value)} placeholder={`Tanya NearS0nn AI tentang ${mode === "debug" ? "bug atau error kode" : mode === "explain" ? "kode yang ingin dipahami" : mode === "chat" ? "pemrograman" : "kode yang ingin dibuat"}...`} rows="1" onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSubmit(e); } }} maxLength={12000} />
            <button className="send-button" type="submit" disabled={busy || !input.trim()} aria-label="Kirim pesan">{busy ? "…" : "↑"}</button>
          </form>
          <div className="composer-note">Enter untuk kirim · Shift + Enter untuk baris baru · Jangan masukkan password atau API key ke chat.</div>
        </footer>
      </main>
    </div>
  );
}